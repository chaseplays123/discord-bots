const { SlashCommandBuilder } = require('discord.js');
const { EmbedBuilder } = require('discord.js');



module.exports = {
  data: new SlashCommandBuilder()
  .setName('startup')
  .setDescription('Startup Command')
  .addStringOption(option => option.setName('reactions')
  .setDescription('minimum reactions for a session')
  .setRequired(true)),
  async execute(interaction) {
    const reactions = interaction.options.getString('reactions')
    const startupEmbed = new EmbedBuilder()
    .setColor(0x9EED00)
    .setTitle('Session Startup')
    .setDescription(`${interaction.user} is doing a session startup we are required to reach ${reactions}+ reactions to begin this session`)
    
    channel = interaction.channel;
    channel.send(`@everyone`)
    channel.send({embeds: [startupEmbed]})
  }
}