const { SlashCommandBuilder } = require('discord.js')
const { EmbedBuilder } = require('discord.js')


module.exports = {
  data: new SlashCommandBuilder()
  .setName('release')
  .setDescription('Release Command')
  .addStringOption(option => option.setName('link')
  .setDescription('minimum reactions for a session')
  .setRequired(true)),
  async execute(interaction) {
    const link = interaction.options.getString('link')
    const releaseEmbed = new EmbedBuilder()
    .setColor(0x9EED00)
    .setTitle('Session Released')
   .setDescription(`${interaction.user}'s session has now released Please grab the link below to join the server Please remember to check out the guidelines and to register your vehicle
   
   
**Link:** ${link}`)
    
    channel = interaction.channel;
    channel.send(`@everyone`)
    channel.send({embeds: [releaseEmbed]})
  }
}