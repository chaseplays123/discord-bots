const { SlashCommandBuilder } = require('discord.js');
const { EmbedBuilder } = require('discord.js');


module.exports = {
  data: new SlashCommandBuilder()
  .setName('early-access')
  .setDescription('sends a embed to the sessions channel'),
  async execute(interaction) {
    const earlyaccessEmbed = new EmbedBuilder()
      .setColor(0x9EED00)
      .setTitle('Session Early Access')
    .setDescription(`${interaction.user} is now doing early access for their session. Please head to the early access channel to join the session`)
  
  channel = interaction.channel
  channel.send(`@everyone`)
  channel.send({embeds: [earlyaccessEmbed]})
  }
}