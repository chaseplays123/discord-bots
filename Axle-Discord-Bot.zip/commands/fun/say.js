const { SlashCommandBuilder } = require('discord.js');


module.exports = {
  data: new SlashCommandBuilder()
  .setName('say')
  .setDescription('Make the bot say something')
  .addStringOption(option => option.setName ('text') 
      .setDescription('The text that the bot is going to say')
          .setRequired(true)),
  async execute(interaction) {
    const text = interaction.options.getString('text'),
      channel = interaction.channel;
    await interaction.reply({content: `Sending message...`, ephemeral: true});
    await channel.send(text);
  }
}